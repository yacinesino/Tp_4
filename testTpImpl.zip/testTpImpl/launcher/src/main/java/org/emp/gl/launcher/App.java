/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.launcher;

import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.impl.gui.Controller;
import org.emp.gl.impl.gui.Environnement;
import org.emp.gl.rebotstate.Movement;
import org.emp.gl.timer.service.impl.withdelegation.TimerServiceImplWithDelegation;


/**
 *
 * @author CONDOR
 */
import org.emp.gl.rebot.Rebot;
import org.emp.gl.timer.service.TimeChangeProvider;
import org.emp.gl.timer.service.TimerChangeListener;

public class App {
    
    static {
        Rebot rebot;
        rebot = new Rebot(1,1);
        Lookup.getInstance().register(Rebot.class, rebot);
        Lookup.getInstance().register(Movement.class, rebot);
        Lookup.getInstance().register(TimeChangeProvider.class, new TimerServiceImplWithDelegation());
        Lookup.getInstance().register(Controller.class, new Controller());
        Lookup.getInstance().register(Environnement.class, new Environnement());
    
    }

    public static void main(String[] args) {
        
        
        //TimerServiceImplWithDelegation s = new TimerServiceImplWithDelegation();
        
        //Controller c = new Controller();
        
        Lookup.getInstance().getService(Controller.class).addMovemenetChangeListener(Lookup.getInstance().getService(Rebot.class));

        Lookup.getInstance().getService(TimeChangeProvider.class).addTimeChangeListener((TimerChangeListener) Lookup.getInstance().getService(Movement.class));
        
        Lookup.getInstance().getService(Rebot.class).addMovemenetChangeListener(Lookup.getInstance().getService(Environnement.class));
        
        Lookup.getInstance().getService(Environnement.class).setVisible(true);
        
        Lookup.getInstance().getService(Controller.class).setVisible(true);
        
        //Lookup.getInstance().getService(Rebot.class).moved();
    }
}
