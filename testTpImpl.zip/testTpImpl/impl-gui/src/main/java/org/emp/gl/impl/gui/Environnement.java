/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.impl.gui;

/**
 *
 * @author CONDOR
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.emp.gl.movement.service.MovementChangeListener;

/**
 *
 * @author CONDOR
 */
public class Environnement extends JFrame implements MovementChangeListener{

    
    private static int extrimitiHeightMax = 11;
    private static int extrimitiHeightheMin = 1;
    private static int extrimitiWidthtMax = 11;
    private static int extrimitiWidtheMin = 1;
    
    public static int getextrimitiHeightMax(){
        return extrimitiHeightMax;
    }
    
    public static int getextrimitiHeightheMin(){
        return extrimitiHeightheMin;
    }
    
    public static int getextrimitiWidthtMax(){
        return extrimitiWidthtMax;
    }
    
    public static int getextrimitiWidtheMin(){
        return extrimitiWidtheMin;
    }
    
    
    private int [][] maze = 
        { {1,1,1,1,1,1,1,1,1,1,1,1,1},
          {1,0,1,0,1,0,1,0,0,0,0,0,1},
          {1,0,1,0,0,0,1,0,1,1,1,0,1},
          {1,0,0,0,1,1,1,0,0,0,0,0,1},
          {1,0,1,0,0,0,0,0,1,1,1,0,1},
          {1,0,1,0,1,1,1,0,1,0,0,0,1},
          {1,0,1,0,1,0,0,0,1,1,1,0,1},
          {1,0,1,0,1,1,1,0,1,0,1,0,1},
          {1,0,0,0,0,0,0,0,0,0,1,0,1},
          {1,0,0,0,0,0,0,0,0,0,1,0,1},
          {1,0,0,0,0,0,0,0,0,0,1,0,1},
          {1,0,0,0,0,0,0,0,0,0,1,9,1},
          {1,1,1,1,1,1,1,1,1,1,1,1,1},
          
        };
    
    private int ballX = 1;
    private int ballY = 1;
    
    public Environnement() {
        
        setTitle("Simple Maze Solver");
        setSize(640, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        
        g.translate(50, 50);
        
        // draw the maze
        for (int row = 0; row < maze.length; row++) {
            for (int col = 0; col < maze[0].length; col++) {
                Color color;
                switch (maze[row][col]) {
                    case 1 : color = Color.BLACK; break;
                    case 9 : color = Color.RED; break;
                    default : color = Color.WHITE;
                }
                g.setColor(color);
                g.fillRect(30 * col, 30 * row, 30, 30);
                g.setColor(Color.BLACK);
                g.drawRect(30 * col, 30 * row, 30, 30);
            }
        }
        
        g.setColor(Color.RED);
        g.fillOval(ballX * 30, ballY * 30, 30, 30);
    }
    
   /* @Override
    protected void processKeyEvent(KeyEvent ke) {
        if (ke.getID() != KeyEvent.KEY_PRESSED) {
            return;
        }
        if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
            ballX += 1;
        }
        else if (ke.getKeyCode() == KeyEvent.VK_LEFT) {
            ballX -= 1;
        }
        else if (ke.getKeyCode() == KeyEvent.VK_UP) {
            ballY -= 1;
            System.out.print(ballY);
            }
        else if (ke.getKeyCode() == KeyEvent.VK_DOWN) {
            ballY += 1;
            System.out.print(ballY);
           
        }
     //repaint();   
    }*/

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        System.out.println("Hello from sky");
         ballX = (int) evt.getOldValue();
         ballY = (int) evt.getNewValue();
         repaint();
    }
}
