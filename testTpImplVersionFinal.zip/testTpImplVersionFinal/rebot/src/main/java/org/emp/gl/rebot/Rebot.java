package org.emp.gl.rebot;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeSupport;
import org.emp.gl.movement.service.MovementChangeListener;
import org.emp.gl.movement.service.MovementChangeProvider;
import org.emp.gl.rebotstate.Down;
import org.emp.gl.rebotstate.Left;
import org.emp.gl.rebotstate.Movement;
import org.emp.gl.rebotstate.RebotState;
import org.emp.gl.rebotstate.Right;
import org.emp.gl.rebotstate.Up;
import org.emp.gl.timer.service.TimerChangeListener;



/**
 *
 * @author CONDOR
 */
public class Rebot implements TimerChangeListener, Movement,MovementChangeListener,MovementChangeProvider{
    RebotState rebotState = new Left(this);
    int positionX;
    int positionY;
    
    private PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    
    
    
    
    public Rebot(int x , int y){
        setPositionX(x);
        setPositionY(y);
    }
  
    @Override
    public int getPositionX(){
        return positionX;
    }
    @Override
    public int getPositionY(){
        return positionY;
    }
    
    @Override
    public void moved(){
        rebotState.move();
    }
    
    @Override
    public void setPositionX(int x){
        this.positionX = x;
    }
    
    @Override
    public void setPositionY(int y){
        this.positionY = y;
    }
    
    @Override
    public void setState(RebotState s)
    {
        this.rebotState = s;
    }
    
    public boolean isObstacle(int val){
        return val == 3 || val == 1;
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if(evt.getPropertyName().equals(TimerChangeListener.EVENT)){
            moved();
        }
        else{ 
            if(evt.getNewValue().equals("Down") && !Up.class.isInstance(this.getState()) ){
                    setState(new Down(this));
            }
            if(evt.getNewValue().equals("Up") && !Down.class.isInstance(this.getState()) ){
                    setState(new Up(this));
            }
            if(evt.getNewValue().equals("Left") && !Right.class.isInstance(this.getState()) ){
                    setState(new Left(this));
            }
            if(evt.getNewValue().equals("Right") && !Left.class.isInstance(this.getState()) ){
                    setState(new Right(this));
            }   
        }
        updateEnvirement();
    }    

    @Override
    public RebotState getState() {
        return this.rebotState;
    }

    @Override
    public void addMovemenetChangeListener(MovementChangeListener pl) {
        pcs.addPropertyChangeListener(pl);
    }

    @Override
    public void removeMovemenetChangeListener(MovementChangeListener pl) {
        pcs.removePropertyChangeListener(pl);
    }
    
    
    public void updateEnvirement(){
        System.out.println(this.getState().getClass().getName().toString());
        PropertyChangeEvent evt = new PropertyChangeEvent(pcs,this.getState().getClass().getName().toString(),getPositionX(),getPositionY());
        pcs.firePropertyChange(evt);
    }

    
}
