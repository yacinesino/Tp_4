package org.emp.gl.timer.service.impl.withdelegation;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeSupport;
import java.util.Timer;
import java.util.TimerTask;
import org.emp.gl.timer.service.TimeChangeProvider;
import org.emp.gl.timer.service.TimerChangeListener;


/**
 *
 * @author CONDOR
 */
public class TimerServiceImplWithDelegation extends TimerTask implements TimeChangeProvider{
    
    private PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    final static String EVENT = "One seconde has passed" ;
    
    
    
    public TimerServiceImplWithDelegation() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(this, 100, 1000);
    }
    
     @Override
    public void run() {
        
        timeChanged();
    }
    
    
    @Override
    public void addTimeChangeListener(TimerChangeListener pl) {
        pcs.addPropertyChangeListener(pl);
    }

    
    @Override
    public void removeTimeChangeListener(TimerChangeListener pl) {
        pcs.removePropertyChangeListener(pl);
    }
    

    private void timeChanged() {
        PropertyChangeEvent evt = new PropertyChangeEvent(pcs, TimerChangeListener.EVENT,null , null);
        pcs.firePropertyChange(evt);
    } 
}
