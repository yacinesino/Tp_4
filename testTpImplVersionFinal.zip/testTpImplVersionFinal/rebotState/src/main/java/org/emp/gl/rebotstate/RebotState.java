/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebotstate;

/**
 *
 * @author CONDOR
 */
public abstract class RebotState {
    public Movement rebot=null;
    
    public RebotState(Movement rebot)
    {
        System.out.println("rebot constcutor");
        
        this.rebot=rebot;   
    }
    
    abstract public void move();
}


