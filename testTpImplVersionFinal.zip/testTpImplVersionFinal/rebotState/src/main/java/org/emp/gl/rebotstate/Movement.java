/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebotstate;

/**
 *
 * @author CONDOR
 */
public interface Movement {
    public void moved();
    public int getPositionX();
    public int getPositionY();
    public void setPositionX(int x);
    public void setPositionY(int y);
    public void setState(RebotState s);
    public RebotState getState();
    
    
}
