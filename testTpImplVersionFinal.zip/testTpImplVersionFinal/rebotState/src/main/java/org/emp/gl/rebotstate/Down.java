/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebotstate;

import org.emp.gl.impl.gui.Environnement;

/**
 *
 * @author CONDOR
 */
public class Down extends RebotState{
    
    public Down(Movement rebot) {
        super(rebot);
    }
    
    @Override
    public void  move() {
        if(rebot.getPositionY() < Environnement.getextrimitiHeightMax() && Environnement.getElementMatrix(rebot.getPositionX(), rebot.getPositionY() + 1 ) != 1){
            System.out.println("position X is " + rebot.getPositionX() + "positionY is "+rebot.getPositionY() );
            rebot.setPositionY((int) (rebot.getPositionY() + 1));
        }  
    }
    
}