/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.test;


import javax.swing.*;
import java.awt.*;
import java.io.*;

public class MazeGUI
{
	public static void main(String[] args) throws IOException, InterruptedException
	{
		try
		{
			int size = Integer.valueOf(args[0]) ;
			
			Maze maze = new Maze(size); // Constructs the maze object
			
			JFrame frame = new JFrame("Maze");
			MazePanel panel = new MazePanel(maze); // Constructs the panel to hold the
			// maze
			JScrollPane scrollPane = new JScrollPane(panel);
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(1000, 800);
			frame.add(scrollPane, BorderLayout.CENTER);
			frame.setVisible(true);
		}
		catch(NumberFormatException exception)
		{
			System.out.println("The input number for the maze size must be an integer") ;
		}
	}
}

// This is the JPanel replacement for mazes that stores as a data
// element the maze and calls the mazes's drawing function
