package org.emp.gl.timer.service;

import java.beans.PropertyChangeListener;

/**
 *
 * @author CONDOR
 */
public interface TimerChangeListener extends PropertyChangeListener{
    final static String EVENT = "One seconde has passed" ;
    
}
