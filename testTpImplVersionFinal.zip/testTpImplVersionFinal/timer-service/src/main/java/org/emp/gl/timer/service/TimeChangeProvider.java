package org.emp.gl.timer.service;

/**
 *
 * @author CONDOR
 */
public interface TimeChangeProvider {

    public void addTimeChangeListener(TimerChangeListener pl);

    public void removeTimeChangeListener(TimerChangeListener pl);
}
