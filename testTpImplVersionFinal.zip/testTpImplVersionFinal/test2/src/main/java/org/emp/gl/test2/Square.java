/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.test2;

import java.util.Random;

/**
 *
 * @author CONDOR
 */
//Box type
class Square{
 
	 static final int INTREE = 1; //The square enters the tree 1
	 static final int NOTINTREE = 0; //The block has not entered the tree 0
	private int x ,flag, y;
	 private Square father; //Father Square
 
	 public Square() {//Construct	
		x=-1;	
		y=-1;	
		flag=NOTINTREE;	
		father=null;
	}
	 public Square(int x, int y) {//Set the xy coordinates of the square	
		super();
		this.x = x;
		this.y = y;
	}
 
	 public int getX() {//Return the x coordinate
		return x;
	}
 
	 public int getY() {//Return y coordinate
		return y;
	}
 
	 public int getFlag() {//Return flag
		return flag;
	}
 
	 public Square getFather() {//Get father square
		return father;
	}
 
	 public void setFather(Square father) {//Set father square
		this.father = father;
	}
 
	 public void setFlag(int flag) {//Set flag
		this.flag = flag;
	}
 
	 public String toString() {//Redefine object output
		return new String("(" + x + "," + y + ")\n");
	}
           private void createMaze() {// randomly generate a maze
		    Random random = new Random();
		    int rx = Math.abs(random.nextInt())%num;
		    int ry = Math.abs(random.nextInt())%num;
		    Stack<Square> s = new Stack<Square>();
		    Square p = maze[rx][ry];
		    Square neis[] = null;
		    s.push(p);
		    while (!s.isEmpty()) {
		      p = s.pop();
		      p.setFlag(Square.INTREE);
		      neis = getNeis(p);
		      int ran = Math.abs(random.nextInt()) % 4;
		      for (int a = 0; a <= 3; a++) {
		        ran++;
		        ran %= 4;
		        if (neis[ran] == null || neis[ran].getFlag() ==Square.INTREE)
		          continue;
		        s.push(neis[ran]);
		        neis[ran].setFather(p);
		      }
		    }
		    // changeFather(maze[0][0],null);
	  }
}
